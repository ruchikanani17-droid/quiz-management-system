// Function to move to the next question
function showNext(currentName, currentId, nextId) {
  /* adding validation on radio button */
  const answers = document.getElementsByName(currentName);
  let selected = false;
  // Check if any radio button is selected
  for (let i = 0; i < answers.length; i++) {
    if (answers[i].checked) {
        selected = true;
        break;
    }
}
  // If none is selected, prevent form submission and show an alert
  if (!selected) {
    alert("Please select your answer before going next.");
  }
  else {
    // Hide the current question
    document.getElementById(currentId).style.display = "none";
    // Show the next question
    document.getElementById(nextId).style.display = "block";
  }
  
}

// Function to calculate the score
function calculateScore(currentName) {
  /* Adding validation on radio button */
  let answers = document.getElementsByName(currentName);
  let selected = false;

  // Check if any radio button is selected
  for (let i = 0; i < answers.length; i++) {
      if (answers[i].checked) {
          selected = true;
          break;
      }
  }
  // If none is selected, prevent form submission and show an alert
  if (!selected) {
      alert("Please select your answer before submitting.");
  } else {
      let score = 0; // Start the score at 0
      // Correct answers for all the questions
      const answers = {
          question1: "Rajam",
          question2: "Khichdi",
          question3: "Bank Clerk",
          question4: "Chanakya",
          question5: "Gangadhar",
          question6: "Ajit",
          question7: "CID",
      };

      const questions = ["question1", "question2", "question3", "question4", "question5", "question6", "question7"]; // List of question names

      for (let i = 0; i < questions.length; i++) {
          const question = questions[i]; // Access each question name
          const options = document.getElementsByName(question); // Get options for the current question
      
          // Loop through options to check if the correct answer is selected
          for (let j = 0; j < options.length; j++) {
              if (options[j].checked && options[j].value === answers[question]) {
                  score++; // Increment score if the answer is correct
                  break; // Stop checking once a correct answer is found
              }
          }
      }
    // Display the score
    document.getElementById("score").textContent = score; // Show the score
    document.getElementById("question-7").style.display = "none"; // Hide the last question
    document.getElementById("result").style.display = "block"; // Show the result section
  } 
}