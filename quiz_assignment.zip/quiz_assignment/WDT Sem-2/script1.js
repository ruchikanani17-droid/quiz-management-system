
// Function to move to the next question
function showNext(currentId, nextId, question) {
    // Hide the current question
    document.getElementById(currentId).style.display = "none";
    // Show the next question
    document.getElementById(nextId).style.display = "block";
  }

// Function to calculate the score
function calculateScore() {
    let score = 0; // Start the score at 0
  
    // All the correct answers in a simple array
    const correctAnswers = ["Rajam", "Khichdi", "Bank Clerk", "Chanakya", "Gangadhar", "Ajit", "CID"];
  
    // Loop through each question (assuming questions are named 'question1', 'question2', etc.)
    for (let i = 1; i <= correctAnswers.length; i++) {
      // Get all options for the current question
      const options = document.getElementsByName(`question{i}`);
  
      // Check which option is selected and if it's correct
      for (let j = 0; j < options.length; j++) {
        if (options[j].checked && options[j].value === correctAnswers[i - 1]) {
          score++; // Increase the score for correct answer
          break; // Stop checking once the correct answer is found
        }
      }
    }
  
    // Display the final score to the user
    alert("Your score is: " + score);
  }
  